#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
uniform vec2 ScreenSize;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

#define EQ(a,b) (length(a - b) < 0.002)

void main() {    
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vec4 texColor = texelFetch(Sampler2, UV2 / 16, 0);
    vertexColor = Color * texColor;
    texCoord0 = UV0;

    if(applySpheyaPacks()) return;

    // Entferne den Textschatten in der BossBar
    // Hauptfarbe: Türkis (64, 224, 208)
    if(EQ(Color.rgb, vec3(254.0/255.0, 253.0/255.0, 4.0/255.0))) {
        vertexColor = texColor;
    }

    // Schattenfarbe: Dunkleres Türkis (16, 56, 52)
    if(EQ(Color.rgb, vec3(63.0/255.0, 63.0/255.0, 1.0/255.0))) {
        gl_Position = vec4(0.0);
    }
}
