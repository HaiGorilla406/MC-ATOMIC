#version 150
#ifndef TEXT_EFFECT
    #define TEXT_EFFECT(r, g, b) void f()
#endif

// owner #AA0000
TEXT_EFFECT(238, 4, 0) {// #EE0400
    apply_iterating_movement();
    override_text_color(rgb(170, 0, 0));
}

// admin #FF4A4A
TEXT_EFFECT(238, 8, 0) { // #EE0800
    apply_iterating_movement();
    override_text_color(rgb(255, 74, 74));
}

// srdev | dev #A9FBF6
TEXT_EFFECT(238, 16, 0) { // #EE1000
    apply_iterating_movement();
    override_text_color(rgb(169,251,246));
}

// mod #e35e54
TEXT_EFFECT(238, 20, 0) { // #EE1400
    apply_iterating_movement();
    override_text_color(rgb(1227,94,84));
}

// content #32ddd3
TEXT_EFFECT(238, 24, 0) { // #EE1800
    apply_iterating_movement();
    override_text_color(rgb(150,221,211));
}

// sup #45bcff
TEXT_EFFECT(238, 28, 0) { // #EE1C00
    apply_iterating_movement();
    override_text_color(rgb(69,188,255));
}

// builder | pr #39ff51
TEXT_EFFECT(238, 32, 0) { // #EE2000
    apply_iterating_movement();
    override_text_color(rgb(170, 0, 170));
}

// cerator #cfa708
TEXT_EFFECT(238, 36, 0) { // #EE2400
    apply_iterating_movement();
    override_text_color(rgb(207,167,8));
}

// deluxe #fffa6e
TEXT_EFFECT(238, 40, 0) { // #EE2800
    apply_iterating_movement();
    override_text_color(rgb(255,250,110));
}

// supreme #ec6eff
TEXT_EFFECT(238, 44, 0) { // #EE2C00
    apply_iterating_movement();
    override_text_color(rgb(236,110,255));
}

// king #ff7272
TEXT_EFFECT(238, 48, 0) { // #EE3000
    apply_iterating_movement();
    override_text_color(rgb(255,114,114));
}

// ultra | youtuber #90f2f8
TEXT_EFFECT(238, 52, 0) { // #EE3400
    apply_iterating_movement();
    override_text_color(rgb(144,242,248));
}

// legend #72ff83
TEXT_EFFECT(238, 56, 0) { // #EE3800
    apply_iterating_movement();
    override_text_color(rgb(114,255,131));
}

// premium #ff9c54
TEXT_EFFECT(238, 60, 0) { // #EE3C00
    apply_iterating_movement();
    override_text_color(rgb(255,156,84));
}

// default #b7b7b7
TEXT_EFFECT(238, 64, 0) { // #EE4000
    apply_iterating_movement();
    override_text_color(rgb(183,183,183));
}

// title end_chest
TEXT_EFFECT(238, 68, 0) { // #EE4400
    apply_waving_movement();
    override_text_color(rgb(84,84,251));
}

// title team
TEXT_EFFECT(238, 72, 0) { // #EE4800
    apply_rainbow();
}

// bossbar outline
TEXT_EFFECT(238, 76, 0) { // #EE4C00
    override_text_color(rgb(255,255,255));
    apply_gradient(rgb(255, 255, 255), rgb(204, 204, 204));
    //apply_thin_outline(rgb(0,0,0));
}

//  -- FLIPPING --
// owner #AA0000
TEXT_EFFECT(238, 80, 0) {// #EE5000
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(170, 0, 0));
}

// admin #FF4A4A
TEXT_EFFECT(238, 84, 0) { // #EE5400
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(255, 74, 74));
}

// srdev | dev #A9FBF6
TEXT_EFFECT(238, 88, 0) { // #EE5800
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(169,251,246));
}

// mod #e35e54
TEXT_EFFECT(238, 92, 0) { // #ee5c00
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(1227,94,84));
}

// content #32ddd3
TEXT_EFFECT(238, 96, 0) { // #ee6000
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(150,221,211));
}

// sup #45bcff
TEXT_EFFECT(238, 100, 0) { // #EE6400
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(69,188,255));
}

// builder | pr #39ff51
TEXT_EFFECT(238, 104, 0) { // #EE6800
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(170, 0, 170));
}

// cerator #cfa708
TEXT_EFFECT(238, 108, 0) { // #EE6C00
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(207,167,8));
}

// deluxe #fffa6e
TEXT_EFFECT(238, 112, 0) { // #EE7000
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(255,250,110));
}

// supreme #ec6eff
TEXT_EFFECT(238, 116, 0) { // #EE7400
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(236,110,255));
}

// king #ff7272
TEXT_EFFECT(238, 120, 0) { // #EE7800
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(255,114,114));
}

// ultra | youtuber #90f2f8
TEXT_EFFECT(238, 124, 0) { // #EE7C00
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(144,242,248));
}

// legend #72ff83
TEXT_EFFECT(238, 128, 0) { // #EE8000
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(114,255,131));
}

// premium #ff9c54
TEXT_EFFECT(238, 132, 0) { // #EE8400
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(255,156,84));
}

// default 
TEXT_EFFECT(238, 136, 0) { // #EE8800
    apply_flipping_movement(0.5, 2);
    override_text_color(rgb(183,183,183));
}


// title ocean_chest
TEXT_EFFECT(238, 140, 0) { // #EE8C00
    apply_gradient(rgb(255,154,8), rgb(206,43,8));
    apply_fire();
}



//  -- Shimmerpräfix --
// owner #AA0000
TEXT_EFFECT(238, 144, 0) {// #EE9000
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(170, 0, 0));
}

// admin #FF4A4A
TEXT_EFFECT(238, 148, 0) { // #EE9400
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(255, 74, 74));
}

// srdev | dev #A9FBF6
TEXT_EFFECT(238, 152, 0) { // #EE9800
    apply_shimmer(0.5, 1.5);
    override_text_color(rgb(169,251,246));
}

// mod #e35e54
TEXT_EFFECT(238, 156, 0) { // #eeac00
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(1227,94,84));
}

// content #32ddd3
TEXT_EFFECT(238, 160, 0) { // #eea000
    apply_shimmer(0.5, 0.8);
    override_text_color(rgb(150,221,211));
}

// sup #45bcff
TEXT_EFFECT(238, 164, 0) { // #EEA400
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(69,188,255));
}

// builder | pr #39ff51
TEXT_EFFECT(238, 168, 0) { // #EEA800
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(170, 0, 170));
}

// cerator #cfa708
TEXT_EFFECT(238, 172, 0) { // #EEAC00
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(207,167,8));
}

// deluxe #fffa6e
TEXT_EFFECT(238, 176, 0) { // #EEB000
    apply_shimmer(0.5, 1.5);
    override_text_color(rgb(255,250,110));
}

// supreme #ec6eff
TEXT_EFFECT(238, 180, 0) { // #EEB400
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(236,110,255));
}

// king #ff7272
TEXT_EFFECT(238, 184, 0) { // #EEB800
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(255,114,114));
}

// ultra | youtuber #90f2f8
TEXT_EFFECT(238, 188, 0) { // #EEBC00
    apply_shimmer(0.5, 1.5);
    override_text_color(rgb(144,242,248));
}

// legend #72ff83
TEXT_EFFECT(238, 192, 0) { // #EEC000
    apply_shimmer(0.5, 1.5);
    override_text_color(rgb(114,255,131));
}

// premium #ff9c54
TEXT_EFFECT(238, 196, 0) { // #EEC400
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(255,156,84));
}

// default 
TEXT_EFFECT(238, 200, 0) { // #EEC800
    apply_shimmer(0.5, 0.8);
    override_text_color(rgb(183,183,183));
}

// polar protector title
TEXT_EFFECT(238, 204, 0) { // #EECC00
    apply_shimmer(0.5, 0.5);
    apply_gradient(rgb(144, 213, 223),rgb(30, 112, 184));
}





//  -- Iteraring Gradient Prefix --
// owner #AA0000
TEXT_EFFECT(238, 208, 0) {// #EED000
    apply_iterating_movement();
    apply_gradient(rgb(170, 0, 0), rgb(242, 121, 121));
}

// admin #FF4A4A
TEXT_EFFECT(238, 212, 0) { // #EED400
    apply_iterating_movement();
    apply_gradient(rgb(255, 74, 74), rgb(247, 190, 190));
}

// srdev | dev #A9FBF6
TEXT_EFFECT(238, 216, 0) { // #EED800
    apply_iterating_movement();
    apply_gradient(rgb(169,251,246), rgb(235, 245, 244));
}

// mod #e35e54
TEXT_EFFECT(238, 220, 0) { // #EEDC00
    apply_iterating_movement();
    apply_gradient(rgb(1227,94,84), rgb(247, 189, 186));
}

// content #32ddd3
TEXT_EFFECT(238, 224, 0) { // #EEE000
    apply_iterating_movement();
    apply_gradient(rgb(150,221,211), rgb(228, 245, 243));
}

// sup #45bcff
TEXT_EFFECT(238, 228, 0) { // #EEE400
    apply_iterating_movement();
    apply_gradient(rgb(69,188,255), rgb(203, 228, 242));
}

// builder | pr #39ff51
TEXT_EFFECT(238, 232, 0) { // #EEE800
    apply_iterating_movement();
    apply_gradient(rgb(170, 0, 170), rgb(242, 160, 242));
}

// cerator #cfa708
TEXT_EFFECT(238, 236, 0) { // #EEEC00
    apply_iterating_movement();
    apply_gradient(rgb(207,167,8), rgb(245, 229, 164));
}

// deluxe #fffa6e
TEXT_EFFECT(238, 240, 0) { // #EEF000
    apply_iterating_movement();
    apply_gradient(rgb(255,250,110), rgb(255, 255, 255));
}

// supreme #ec6eff
TEXT_EFFECT(238, 244, 0) { // #EEF400
    apply_iterating_movement();
    apply_gradient(rgb(236,110,255), rgb(244, 205, 250));
}

// king #ff7272
TEXT_EFFECT(238, 248, 0) { // #EEF800
    apply_iterating_movement();
    apply_gradient(rgb(255,114,114), rgb(252, 210, 210));
}

// ultra | youtuber #90f2f8
TEXT_EFFECT(238, 252, 0) { // #EEFC00
    apply_iterating_movement();
    apply_gradient(rgb(144,242,248), rgb(255, 255, 255));
}

// legend #72ff83
TEXT_EFFECT(238, 0, 4) { // #EE0004
    apply_iterating_movement();
    apply_gradient(rgb(114,255,131), rgb(227, 250, 230));
}

// premium #ff9c54
TEXT_EFFECT(238, 4, 4) { // #EE0404
    apply_iterating_movement();
    apply_gradient(rgb(255,156,84), rgb(255, 255, 255));
}

// default 
TEXT_EFFECT(238, 8, 4) { // #EE0804
    apply_iterating_movement();
    apply_gradient(rgb(183,183,183), rgb(255, 255, 255));
}

// title cave_explorer_elite
TEXT_EFFECT(238, 12, 4) { // #EE0C04
    apply_shimmer(0.5, 0.5);
    apply_gradient(rgb(0, 170, 0),rgb(85, 255, 85));
}

// title vote master
TEXT_EFFECT(238, 16, 4) { // #EE1004
    apply_iterating_movement();
    apply_gradient(rgb(238,190,120),rgb(113, 70, 42));
}



//  -- Metallic Prefix --
// owner #AA0000
TEXT_EFFECT(238, 20, 4) {// #ee1404
    apply_metalic(rgb(170, 0, 0));
}

// admin #FF4A4A
TEXT_EFFECT(238, 24, 4) { // #ee1804
    apply_metalic(rgb(255, 74, 74));
}

// srdev | dev #A9FBF6
TEXT_EFFECT(238, 28, 4) { // #ee1c04
    apply_metalic(rgb(169,251,246));
}

// mod #e35e54
TEXT_EFFECT(238, 40, 4) { // #ee2804
    apply_metalic(rgb(1227,94,84));
}

// content #32ddd3
TEXT_EFFECT(238, 44, 4) { // #ee2c04
    apply_metalic(rgb(150,221,211));
}

// sup #45bcff
TEXT_EFFECT(238, 48, 4) { // #ee3004
    apply_metalic(rgb(69,188,255));
}

// builder | pr #39ff51
TEXT_EFFECT(238, 52, 4) { // #ee3404
    apply_metalic(rgb(170, 0, 170));
}

// cerator #cfa708
TEXT_EFFECT(238, 56, 4) { // #ee3804
    apply_metalic(rgb(207,167,8));
}

// deluxe #fffa6e
TEXT_EFFECT(238, 60, 4) { // #ee3c04
    apply_metalic(rgb(255,250,110));
}

// supreme #ec6eff
TEXT_EFFECT(238, 64, 4) { // #ee4004
    apply_metalic(rgb(236,110,255));
}

// king #ff7272
TEXT_EFFECT(238, 68, 4) { // #ee4404
    apply_metalic(rgb(255,114,114));
}

// ultra | youtuber #90f2f8
TEXT_EFFECT(238, 72, 4) { // #ee4804
    apply_metalic(rgb(144,242,248));
}

// legend #72ff83
TEXT_EFFECT(238, 76, 4) { // #ee4c04
    apply_metalic(rgb(114,255,131));
}

// premium #ff9c54
TEXT_EFFECT(238, 80, 4) { // #ee5004
    apply_metalic(rgb(255,156,84));
}

// default 
TEXT_EFFECT(238, 84, 4) { // #ee5404
    apply_metalic(rgb(183,183,183));
}

// default 
TEXT_EFFECT(238, 88, 4) { // #ee5804
    apply_shimmer(0.5, 0.5);
    override_text_color(rgb(69,199,255));
}