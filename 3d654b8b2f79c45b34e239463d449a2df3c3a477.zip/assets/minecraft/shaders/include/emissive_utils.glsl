#version 150

vec4 make_emissive(vec4 defaultColor, vec4 pixelColor, vec4 vertexColor, vec4 ColorModulator) {
    float alpha = pixelColor.a;

    if (alpha == 254./255.) {
        alpha = 1;
        return pixelColor * mix(vertexColor, vec4(1.), 2) * ColorModulator;
    } else if (alpha == 253./255.) {
        alpha = 230./255.; // 90% transparency
        return pixelColor * mix(vertexColor, vec4(1.), 2) * ColorModulator;
    } else if (alpha == 252./255.) {
        alpha = 204./255.; // 80% transparency
        return pixelColor * mix(vertexColor, vec4(1.), 2) * ColorModulator;
    } else if (alpha == 251./255.) {
        alpha = 153./255.; // 60% transparency
        return pixelColor * mix(vertexColor, vec4(1.), 2) * ColorModulator;
    } else if (alpha == 250./255.) {
        alpha = 102./255.; // 40% transparency
        return pixelColor * mix(vertexColor, vec4(1.), 2) * ColorModulator;
    } else if (alpha == 249./255.) {
        alpha = 1;
        return pixelColor * vertexColor * vec4(2.) * ColorModulator;
    }

    return defaultColor;
}
