#version 150
#define VSH
#define RENDERTYPE_TEXT

#moj_import <fog.glsl>

// These are inputs and outputs to the shader
// If you are merging with a shader, put any inputs and outputs that they have, but are not here already, in the list below
in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
uniform float GameTime;
uniform vec2 ScreenSize;

out float vertexDistance;
out vec4 baseColor;
out vec4 lightColor;
out vec4 vertexColor;
out vec2 texCoord0;

#moj_import <spheya_packs_impl.glsl>

#define EQ(a,b) (length(a - b) < 0.002)

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    baseColor = Color;
    lightColor = texelFetch(Sampler2, UV2 / 16, 0);
    vertexColor = baseColor * lightColor;
    vertexDistance = fog_distance(Position, FogShape);
    texCoord0 = UV0;

    if(applySpheyaPacks()) return;

    if(EQ(Color.rgb, vec3(254.0/255.0, 253.0/255.0, 4.0/255.0))) {
        vertexColor = lightColor;
    }

    if(EQ(Color.rgb, vec3(63.0/255.0, 63.0/255.0, 1.0/255.0))) {
        gl_Position = vec4(0.0);
    }
}
